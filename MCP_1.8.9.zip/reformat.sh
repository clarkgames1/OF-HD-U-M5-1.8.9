#!/bin/bash
python runtime/reformat.py "$@"
